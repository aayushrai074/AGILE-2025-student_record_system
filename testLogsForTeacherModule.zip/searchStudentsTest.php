<?php
use PHPUnit\Framework\TestCase;

class SearchStudentsTest extends TestCase
{
    private $pdo;

    protected function setUp(): void
    {
        $this->pdo = new PDO('mysql:host=localhost;dbname=test_db', 'root', '');
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Insert dummy student records
        $this->pdo->exec("INSERT INTO student (student_id, name, email) VALUES 
            ('40129', 'Binita Gurung', 'binita@example.com'),
            ('40130', 'Bimala Tamang', 'bimala@example.com')");
    }

    public function testSearchByNameReturnsCorrectStudent()
    {
        $searchTerm = 'Bimala';

        $stmt = $this->pdo->prepare("SELECT student_id, name, email FROM student WHERE student_id LIKE ? OR name LIKE ?");
        $stmt->execute(["%$searchTerm%", "%$searchTerm%"]);

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $this->assertCount(1, $results);
        $this->assertEquals('40130', $results[0]['student_id']);
        $this->assertEquals('Bimala Tamang', $results[0]['name']);
    }

    public function testSearchByPartialIDReturnsCorrectStudent()
    {
        $searchTerm = '401';

        $stmt = $this->pdo->prepare("SELECT student_id, name, email FROM student WHERE student_id LIKE ? OR name LIKE ?");
        $stmt->execute(["%$searchTerm%", "%$searchTerm%"]);

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $this->assertGreaterThanOrEqual(2, count($results));
        $this->assertEquals('40129', $results[0]['student_id']);
        $this->assertEquals('40130', $results[1]['student_id']);
    }

    protected function tearDown(): void
    {
        $this->pdo->exec("DELETE FROM student WHERE student_id IN ('40129', '40130')");
    }
}
