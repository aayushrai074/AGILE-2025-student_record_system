<?php
use PHPUnit\Framework\TestCase;

class DeleteAssignmentTest extends TestCase
{
    protected $pdo;
    protected $testAssignmentId;

    protected function setUp(): void
    {
        $dsn = "mysql:host=localhost;dbname=your_database;charset=utf8mb4";
        $this->pdo = new PDO($dsn, 'your_username', 'your_password');
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Insert a test record for deletion
        $stmt = $this->pdo->prepare("INSERT INTO assignments (teacher_id, code, title, file_name, file_path) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([1001, 'AS901', 'Test Delete', 'test_file.txt', 'uploads/test_file.txt']);

        $this->testAssignmentId = $this->pdo->lastInsertId();

        // Create dummy file to delete
        if (!file_exists('uploads')) mkdir('uploads');
        file_put_contents('uploads/test_file.txt', 'Dummy content');
    }

    public function testAssignmentDeletion()
    {
        // First ensure the assignment exists
        $stmt = $this->pdo->prepare("SELECT * FROM assignments WHERE id = ?");
        $stmt->execute([$this->testAssignmentId]);
        $assignment = $stmt->fetch();

        $this->assertNotEmpty($assignment, "Assignment should exist before deletion");
        $this->assertFileExists($assignment['file_path']);

        // Simulate deletion logic
        unlink($assignment['file_path']); // Delete file
        $del = $this->pdo->prepare("DELETE FROM assignments WHERE id = ? AND teacher_id = ?");
        $del->execute([$this->testAssignmentId, 1001]);

        // Verify it's deleted
        $stmt = $this->pdo->prepare("SELECT * FROM assignments WHERE id = ?");
        $stmt->execute([$this->testAssignmentId]);
        $deleted = $stmt->fetch();

        $this->assertFalse($deleted, "Assignment should be deleted from DB");
        $this->assertFileDoesNotExist('uploads/test_file.txt', "Assignment file should be deleted");
    }

    protected function tearDown(): void
    {
        // Clean up if still exists
        if (file_exists('uploads/test_file.txt')) {
            unlink('uploads/test_file.txt');
        }

        $this->pdo->prepare("DELETE FROM assignments WHERE id = ?")->execute([$this->testAssignmentId]);
    }
}
