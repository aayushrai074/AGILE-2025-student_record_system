<?php
use PHPUnit\Framework\TestCase;

class ViewTeacherClassesTest extends TestCase
{
    protected $pdo;
    protected $teacher_id = 1001;

    protected function setUp(): void
    {
        $dsn = "mysql:host=localhost;dbname=your_database;charset=utf8mb4";
        $this->pdo = new PDO($dsn, 'your_username', 'your_password');
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Clean previous test records if needed
        $this->pdo->prepare("DELETE FROM course WHERE code = 'TEST101'")->execute();

        // Insert test course
        $stmt = $this->pdo->prepare("INSERT INTO course (code, name, description, type, teacher_id) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['TEST101', 'Test Course', 'For PHPUnit Test', 'Lecture', $this->teacher_id]);
    }

    public function testAssignedCoursesAreFetched()
    {
        $stmt = $this->pdo->prepare("SELECT code, name, description, type FROM course WHERE teacher_id = ?");
        $stmt->execute([$this->teacher_id]);
        $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $this->assertNotEmpty($courses, "Courses should be returned for teacher_id 1001");
        $found = false;
        foreach ($courses as $course) {
            if ($course['code'] === 'TEST101') {
                $found = true;
                $this->assertEquals('Test Course', $course['name']);
                $this->assertEquals('For PHPUnit Test', $course['description']);
                $this->assertEquals('Lecture', $course['type']);
            }
        }
        $this->assertTrue($found, "Test course TEST101 should be in result");
    }

    protected function tearDown(): void
    {
        // Remove test course
        $this->pdo->prepare("DELETE FROM course WHERE code = 'TEST101'")->execute();
    }
}
