<?php

use PHPUnit\Framework\TestCase;

class EditTeacherTest extends TestCase
{
    public function testQualificationLength()
    {
        $input = str_repeat("A", 110);
        $this->assertTrue(strlen($input) <= 110);
    }

    public function testQualificationTooLong()
    {
        $input = str_repeat("A", 111);
        $this->assertFalse(strlen($input) <= 110);
    }

    public function testEmailFormat()
    {
        $this->assertMatchesRegularExpression('/^[^@]+@[^@]+\.[a-z]+$/', 'john@example.com');
        $this->assertDoesNotMatchRegularExpression('/^[^@]+@[^@]+\.[a-z]+$/', 'johnexample.com');
    }
}
