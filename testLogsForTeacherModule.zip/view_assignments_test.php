<?php
use PHPUnit\Framework\TestCase;

class ViewAssignmentsTest extends TestCase
{
    protected $pdo;

    protected function setUp(): void
    {
        $host = 'localhost';
        $db   = 'your_database';
        $user = 'your_username';
        $pass = 'your_password';

        $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
        $this->pdo = new PDO($dsn, $user, $pass);
    }

    public function testAssignmentsAreListedForTeacher()
    {
        $teacher_id = 1001;

        $stmt = $this->pdo->prepare("SELECT a.id, a.title, a.file_name, a.file_path, c.name, a.uploaded_at
                                     FROM assignments a
                                     JOIN course c ON a.code = c.code
                                     WHERE a.teacher_id = ?
                                     ORDER BY a.uploaded_at DESC");
        $stmt->execute([$teacher_id]);
        $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $this->assertIsArray($assignments);
        $this->assertNotEmpty($assignments);

        foreach ($assignments as $assignment) {
            $this->assertArrayHasKey('title', $assignment);
            $this->assertArrayHasKey('file_name', $assignment);
        }
    }

    public function testFilterByTeacherReturnsCorrectTeacher()
    {
        $teacher_id = 1001;

        $stmt = $this->pdo->prepare("SELECT teacher_id FROM assignments WHERE teacher_id = ?");
        $stmt->execute([$teacher_id]);
        $results = $stmt->fetchAll(PDO::FETCH_COLUMN);

        foreach ($results as $tid) {
            $this->assertEquals(1001, $tid);
        }
    }
}
