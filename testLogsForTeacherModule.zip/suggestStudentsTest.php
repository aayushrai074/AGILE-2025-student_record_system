<?php
use PHPUnit\Framework\TestCase;

class SuggestStudentsTest extends TestCase
{
    private $pdo;

    protected function setUp(): void
    {
        // Connect to the test database
        $this->pdo = new PDO('mysql:host=localhost;dbname=test_db', 'root', '');
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare dummy data
        $this->pdo->exec("INSERT INTO student (student_id, name) VALUES ('40111', 'Jack Forsman'), ('40112', 'Lucas Hansen')");
    }

    public function testSuggestStudentsReturnsMatchingData()
    {
        $term = 'Al';
        $stmt = $this->pdo->prepare("SELECT student_id, name FROM student WHERE name LIKE ? OR student_id LIKE ? LIMIT 10");
        $stmt->execute(["%$term%", "%$term%"]);

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $this->assertNotEmpty($results, "Expected matching students for term '$term'");
        $this->assertEquals('Jack Forsman', $results[0]['name']);
    }

    protected function tearDown(): void
    {
        // Clean up
        $this->pdo->exec("DELETE FROM student WHERE student_id IN ('40111', '40112')");
    }
}
?>