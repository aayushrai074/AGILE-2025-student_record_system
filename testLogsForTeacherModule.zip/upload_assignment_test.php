<?php
use PHPUnit\Framework\TestCase;

class AssignmentTest extends TestCase
{
    public function testValidTitleLength()
    {
        $title = str_repeat("A", 255);
        $this->assertTrue(strlen($title) <= 255);
    }

    public function testTitleTooLong()
    {
        $title = str_repeat("A", 256);
        $this->assertFalse(strlen($title) <= 255);
    }

    public function testCodeIsValidFormat()
    {
        $code = "AS901";
        $this->assertMatchesRegularExpression('/^[A-Z]{2,5}\d{3}$/', $code);
    }
}
